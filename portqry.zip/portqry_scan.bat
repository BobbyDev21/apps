@echo off
setlocal EnableDelayedExpansion
CLS
:: ============================================================
::  portqry_scan.bat
::
::  Reads:    ips.txt    - one destination IP per line
::            ports.txt  - one port number per line (TCP)
::
::  Requires: portqry.exe in PATH or same folder as this script
::
::  Output:   portqry_results.csv   - scan results
::            portqry_scan.log      - full activity log
::
::  CSV columns:
::    ComputerName, IPAddress, DestinationIP, Port, Result, ScanDate
:: ============================================================

set "SCRIPT_DIR=%~dp0"
set "IPS_FILE=%SCRIPT_DIR%ips.txt"
set "PORTS_FILE=%SCRIPT_DIR%ports.txt"
set "OUTPUT=%SCRIPT_DIR%portqry_results.csv"
set "LOGFILE=%SCRIPT_DIR%portqry_scan.log"
set "PORTQRY=portqry.exe"

:: ---------- Capture scan timestamp via wmic ----------
for /f "skip=1 tokens=1" %%D in ('wmic os get LocalDateTime 2^>nul') do (
    if not "%%D"=="" (
        set "DT=%%D"
        goto :GOT_DT
    )
)
:GOT_DT
set "SCAN_DATE=!DT:~0,4!-!DT:~4,2!-!DT:~6,2!"
set "SCAN_TIME=!DT:~8,2!:!DT:~10,2!:!DT:~12,2!"
set "SCAN_DATETIME=!SCAN_DATE! !SCAN_TIME!"

goto :MAIN

:: ---------- LOG subroutine: echoes to console AND appends to log ----------
:LOG
    set "LOGMSG=%~1"
    if "!LOGMSG!"=="." (
        echo.
        echo. >> "%LOGFILE%"
    ) else (
        echo(!LOGMSG!
        echo(!LOGMSG! >> "%LOGFILE%"
    )
    goto :eof

:LOGRAW
    :: Appends a line to log only (no console), used for raw portqry output
    echo %~1 >> "%LOGFILE%"
    goto :eof

:MAIN

:: ---------- Initialise log file (overwrite previous run) ----------
(
echo ============================================================
echo  portqry_scan.bat - Scan Log
echo  Scan started : !SCAN_DATETIME!
echo  Host         : %COMPUTERNAME%
echo ============================================================
) > "%LOGFILE%"

call :LOG "============================================================"
call :LOG " portqry_scan.bat  |  Scan started: !SCAN_DATETIME!"
call :LOG "============================================================"
call :LOG "."

:: ---------- Sanity checks ----------
if not exist "%IPS_FILE%" (
    call :LOG "[ERROR] ips.txt not found: %IPS_FILE%"
    exit /b 1
)
if not exist "%PORTS_FILE%" (
    call :LOG "[ERROR] ports.txt not found: %PORTS_FILE%"
    exit /b 1
)

where %PORTQRY% >nul 2>&1
if errorlevel 1 (
    if not exist "%SCRIPT_DIR%%PORTQRY%" (
        call :LOG "[ERROR] portqry.exe not found in PATH or script folder."
        exit /b 1
    )
    set "PORTQRY=%SCRIPT_DIR%portqry.exe"
)

:: ---------- Get local primary IPv4 (Sanitized) ----------
set "LOCAL_IP=UNKNOWN"
for /f "tokens=2 delims=:" %%A in ('ipconfig ^| findstr /i "IPv4"') do (
    for /f "tokens=*" %%B in ("%%A") do set "LOCAL_IP=%%B"
    goto :GOT_LOCAL_IP
)
:GOT_LOCAL_IP

call :LOG "[INFO] Computer Name : %COMPUTERNAME%"
call :LOG "[INFO] Local IP      : !LOCAL_IP!"
call :LOG "[INFO] Scan DateTime : !SCAN_DATETIME!"
call :LOG "."

:: ---------- Write CSV header ----------
echo ComputerName,IPAddress,DestinationIP,Port,Result,ScanDate> "%OUTPUT%"

call :LOG "[INFO] CSV output    : %OUTPUT%"
call :LOG "[INFO] Log file      : %LOGFILE%"
call :LOG "."

:: ---------- Load ports into indexed array (skipping # and blank lines) ----------
set "PORT_COUNT=0"
for /f "usebackq eol=# tokens=*" %%P in ("%PORTS_FILE%") do (
    set "PORT[!PORT_COUNT!]=%%P"
    set /a PORT_COUNT+=1
)

:: ---------- Load IPs into indexed array (skipping # and blank lines) ----------
set "IP_COUNT=0"
for /f "usebackq eol=# tokens=*" %%I in ("%IPS_FILE%") do (
    set "IP[!IP_COUNT!]=%%I"
    set /a IP_COUNT+=1
)

call :LOG "[INFO] Loaded !IP_COUNT! IP(s) from ips.txt"
call :LOG "[INFO] Loaded !PORT_COUNT! port(s) from ports.txt"
call :LOG "."
call :LOG "------------------------------------------------------------"
call :LOG " Starting scan  (!IP_COUNT! IPs x !PORT_COUNT! ports)"
call :LOG "------------------------------------------------------------"
call :LOG "."

:: ---------- Main scan loop ----------
set "ROW_COUNT=0"
set /a LAST_IP=!IP_COUNT!-1
set /a LAST_PORT=!PORT_COUNT!-1

if !LAST_IP! LSS 0 (
    call :LOG "[WARN] No IPs to scan."
    goto :FINISH
)

for /l %%I in (0,1,!LAST_IP!) do (
    set "DEST_IP=!IP[%%I]!"
    call :LOG "[TARGET] !DEST_IP!"

    for /l %%N in (0,1,!LAST_PORT!) do (
        set "PORT_NUM=!PORT[%%N]!"
        set "RESULT=UNKNOWN"

        :: Run portqry and capture output
        "!PORTQRY!" -n !DEST_IP! -e !PORT_NUM! -p TCP > "%TEMP%\pqry_out.tmp" 2>&1

        :: Append raw portqry output to log file only
        echo         [portqry raw - !DEST_IP!:!PORT_NUM!/TCP]>> "%LOGFILE%"
        type "%TEMP%\pqry_out.tmp" >> "%LOGFILE%"
        echo.>> "%LOGFILE%"

        :: Parse result keywords (Order matches hierarchy)
        findstr /c:"LISTENING" "%TEMP%\pqry_out.tmp" >nul 2>&1 && set "RESULT=LISTENING"
        findstr /c:"FILTERED" "%TEMP%\pqry_out.tmp" >nul 2>&1 && set "RESULT=FILTERED"
        findstr /c:"NOT LISTENING" "%TEMP%\pqry_out.tmp" >nul 2>&1 && set "RESULT=NOT LISTENING"

        :: Write CSV row
        echo %COMPUTERNAME%,!LOCAL_IP!,!DEST_IP!,!PORT_NUM!,!RESULT!,!SCAN_DATETIME!>> "%OUTPUT%"

        call :LOG "         Port !PORT_NUM!/TCP  -->  !RESULT!"
        set /a ROW_COUNT+=1
    )
    call :LOG "."
)

:FINISH
:: ---------- Cleanup ----------
if exist "%TEMP%\pqry_out.tmp" del "%TEMP%\pqry_out.tmp"

:: ---------- Footer ----------
call :LOG "============================================================"
call :LOG " Scan complete!"
call :LOG " Total rows written : !ROW_COUNT!"
call :LOG " CSV  -> %OUTPUT%"
call :LOG " Log  -> %LOGFILE%"
call :LOG "============================================================"

echo.
echo --- CSV Preview ---
type "%OUTPUT%"
echo.
endlocal
