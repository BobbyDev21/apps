# Configuration
$port = 8443
$dashboardPath = "C:\ServiceMonitor\Dashboard\status.html"
$prefix = "http://+:$port/"

# Create listener
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($prefix)
$listener.Start()
Write-Host "Dashboard server started on $prefix" -ForegroundColor Cyan

while ($listener.IsListening) {
    try {
        $context = $listener.GetContext()
        $response = $context.Response
        $request = $context.Request

        if (Test-Path $dashboardPath) {
            $html = Get-Content $dashboardPath -Raw
            $buffer = [System.Text.Encoding]::UTF8.GetBytes($html)
            $response.ContentType = "text/html"
            $response.ContentLength64 = $buffer.Length
            $response.OutputStream.Write($buffer, 0, $buffer.Length)
        } else {
            $errorMsg = "<html><body><h2>Dashboard not found.</h2></body></html>"
            $buffer = [System.Text.Encoding]::UTF8.GetBytes($errorMsg)
            $response.StatusCode = 404
            $response.ContentType = "text/html"
            $response.OutputStream.Write($buffer, 0, $buffer.Length)
        }

        $response.OutputStream.Close()
    } catch {
        Write-Host "Error serving dashboard: $_" -ForegroundColor Red
    }
}