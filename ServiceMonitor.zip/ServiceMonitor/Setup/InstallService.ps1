# Paths
$serviceName = "ServiceMonitor"
$monitorScript = "C:\ServiceMonitor\StartMonitor.bat"

# Create service
Write-Host "Creating Windows service '$serviceName'..." -ForegroundColor Cyan
sc.exe create $serviceName binPath= "`"$monitorScript`"" start= auto

# Start service
Start-Sleep -Seconds 2
sc.exe start $serviceName

Write-Host "Service '$serviceName' installed and started successfully." -ForegroundColor Green