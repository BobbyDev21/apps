$serviceName = "ServiceMonitor"
Write-Host "Stopping and removing service '$serviceName'..." -ForegroundColor Yellow
sc.exe stop $serviceName
Start-Sleep -Seconds 2
sc.exe delete $serviceName
Write-Host "Service removed." -ForegroundColor Green