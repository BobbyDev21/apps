📘 README: Service Monitor Deployment Guide

Overview

This PowerShell-based service monitor continuously checks the health of specified Windows services, logs issues, updates an HTML dashboard, and integrates with Event Viewer. It can be run interactively or installed as a Windows service.

Folder Structure

C:\ServiceMonitor\
├── Config\
│   └── Services.txt
├── Scripts\
│   └── HandleServiceIssue.bat
├── Logs\
│   └── ServiceMonitor.log
├── Dashboard\
│   └── status.html
└── MonitorServices.ps1

**Setup Instructions**

**Edit** Services.txt

List each service name on a new line.

Use sc query or Get-Service to find exact names.

**Customize** HandleServiceIssue.bat

Add logic to log, restart, or notify based on service issues.

**Run the Monitor**

Launch MonitorServices.ps1 in PowerShell.

Ensure execution policy allows script execution.

**Install as a Windows Service**

Use InstallService.ps1 to register the monitor as a service.

Use **UninstallService.ps1** to remove it.

**Notes**

Dashboard auto-refreshes every 30 seconds.

Event Viewer entries use source ServiceMonitor under Application log.

Script handles missing services and hung processes gracefully.