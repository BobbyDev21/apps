# Configuration
$serviceListPath = "C:\ServiceMonitor\Config\Services.txt"
$batchScriptPath = "C:\ServiceMonitor\Scripts\HandleServiceIssue.bat"
$logPath = "C:\ServiceMonitor\Logs\ServiceMonitor.log"
$dashboardPath = "C:\ServiceMonitor\Dashboard\status.html"
$eventSource = "ServiceMonitor"
$eventLogName = "Application"
$checkInterval = 60  # seconds

# Ensure directories exist
foreach ($path in @($logPath, $dashboardPath)) {
    $dir = Split-Path $path
    if (-not (Test-Path $dir)) {
        New-Item -Path $dir -ItemType Directory | Out-Null
    }
}

# Register Event Viewer source if missing
if (-not [System.Diagnostics.EventLog]::SourceExists($eventSource)) {
    New-EventLog -LogName $eventLogName -Source $eventSource
}

# Function: Write to log file
function Write-Log {
    param([string]$message)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path $logPath -Value "$timestamp - $message"
}

# Function: Write to Event Viewer
function Write-EventLogEntry {
    param(
        [string]$message,
        [string]$entryType = "Error"  # Options: Error, Warning, Information
    )
    Write-EventLog -LogName $eventLogName -Source $eventSource -EntryType $entryType -EventId 1000 -Message $message
}

# Function: Check service health
function Check-ServiceHealth {
    $services = Get-Content -Path $serviceListPath | Where-Object { $_ -and $_ -notmatch '^#' }

    foreach ($svc in $services) {
        $status = "Unknown"
        $color = "gray"
        $service = Get-Service -Name $svc -ErrorAction SilentlyContinue

        if ($null -eq $service) {
            $msg = "Service '$svc' not found."
            Write-Log $msg
            Write-EventLogEntry $msg "Warning"
            & $batchScriptPath "`"$msg`""
            $status = "Not Found"
            $color = "orange"
            continue
        }

        if ($service.Status -ne 'Running') {
            $msg = "Service '$svc' is not running. Status: $($service.Status)"
            Write-Log $msg
            Write-EventLogEntry $msg "Error"
            & $batchScriptPath "`"$msg`""
            $status = $service.Status
            $color = "red"
            continue
        }

        try {
            $proc = Get-Process -Id $service.Id -ErrorAction SilentlyContinue
            if ($proc -and $proc.Responding -eq $false) {
                $msg = "Service '$svc' is running but not responding (hung)."
                Write-Log $msg
                Write-EventLogEntry $msg "Error"
                & $batchScriptPath "`"$msg`""
                $status = "Hung"
                $color = "red"
            } else {
                $status = "Running"
                $color = "green"
                Write-Log "Service '$svc' is healthy."
            }
        } catch {
            $msg = "Could not verify responsiveness for '$svc'."
            Write-Log $msg
            Write-EventLogEntry $msg "Warning"
        }

        # Store status for dashboard
        $global:dashboardRows += "<tr><td>$svc</td><td style='color:$color;font-weight:bold;'>$status</td></tr>"
    }
}

# Function: Update HTML dashboard
function Update-Dashboard {
    $html = @"
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv='refresh' content='30'>
    <title>Service Monitor Dashboard</title>
    <style>
        body { font-family: Arial; background: #f4f4f4; padding: 20px; }
        table { border-collapse: collapse; width: 50%; margin: auto; background: #fff; }
        th, td { border: 1px solid #ccc; padding: 10px; text-align: left; }
        th { background: #eee; }
        caption { font-size: 1.5em; margin-bottom: 10px; }
    </style>
</head>
<body>
    <table>
        <caption>Service Health Dashboard</caption>
        <tr><th>Service Name</th><th>Status</th></tr>
        $($global:dashboardRows -join "`n")
    </table>
</body>
</html>
"@
    Set-Content -Path $dashboardPath -Value $html
    $global:dashboardRows = @()  # Reset for next cycle
}

# Main monitoring loop
while ($true) {
    $global:dashboardRows = @()
    Check-ServiceHealth
    Update-Dashboard
    Start-Sleep -Seconds $checkInterval
}