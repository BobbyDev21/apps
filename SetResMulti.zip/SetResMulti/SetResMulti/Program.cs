using System;
using System.Runtime.InteropServices;

namespace SetResMulti
{
    class Program
    {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        public struct DISPLAY_DEVICE
        {
            public int cb;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
            public string DeviceName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
            public string DeviceString;
            public int StateFlags;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
            public string DeviceID;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
            public string DeviceKey;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct DEVMODE
        {
            private const int CCHDEVICENAME = 32;
            private const int CCHFORMNAME = 32;

            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = CCHDEVICENAME)]
            public string dmDeviceName;
            public short dmSpecVersion;
            public short dmDriverVersion;
            public short dmSize;
            public short dmDriverExtra;
            public int dmFields;

            public int dmPositionX;
            public int dmPositionY;
            public int dmDisplayOrientation;
            public int dmDisplayFixedOutput;

            public short dmColor;
            public short dmDuplex;
            public short dmYResolution;
            public short dmTTOption;
            public short dmCollate;

            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = CCHFORMNAME)]
            public string dmFormName;

            public short dmLogPixels;
            public int dmBitsPerPel;
            public int dmPelsWidth;
            public int dmPelsHeight;
            public int dmDisplayFlags;
            public int dmDisplayFrequency;

            public int dmICMMethod;
            public int dmICMIntent;
            public int dmMediaType;
            public int dmDitherType;
            public int dmReserved1;
            public int dmReserved2;

            public int dmPanningWidth;
            public int dmPanningHeight;
        }

        [DllImport("user32.dll")]
        public static extern bool EnumDisplayDevices(string lpDevice, uint iDevNum, ref DISPLAY_DEVICE lpDisplayDevice, uint dwFlags);

        [DllImport("user32.dll")]
        public static extern bool EnumDisplaySettings(string deviceName, int modeNum, ref DEVMODE devMode);

        [DllImport("user32.dll")]
        public static extern int ChangeDisplaySettingsEx(string lpszDeviceName, ref DEVMODE lpDevMode, IntPtr hwnd, uint dwflags, IntPtr lParam);

        const int ENUM_CURRENT_SETTINGS = -1;
        const int CDS_UPDATEREGISTRY = 0x01;
        const int CDS_RESET = 0x40000000;
        const int DISP_CHANGE_SUCCESSFUL = 0;
        const int DM_PELSWIDTH = 0x80000;
        const int DM_PELSHEIGHT = 0x100000;
        const int DM_BITSPERPEL = 0x40000;
        const int DM_DISPLAYFREQUENCY = 0x400000;

        static void Main(string[] args)
        {
            Logger.Info("Starting SetRes utility...");
            Logger.Info("Arguments: " + string.Join(" ", args));

            try
            {
                if (args.Length == 1 && args[0].Equals("--list", StringComparison.OrdinalIgnoreCase))
                {
                    ListMonitors();
                    return;
                }

                if (args.Length < 5)
                {
                    Logger.Error("Insufficient arguments provided.");
                    Console.WriteLine("Usage:");
                    Console.WriteLine("  SetRes.exe [width] [height] [depth] [frequency] [monitorIndex]");
                    Console.WriteLine("  SetRes.exe --list");
                    return;
                }

                int width = int.Parse(args[0]);
                int height = int.Parse(args[1]);
                int depth = int.Parse(args[2]);
                int frequency = int.Parse(args[3]);
                int monitorIndex = int.Parse(args[4]);

                DISPLAY_DEVICE d = new DISPLAY_DEVICE();
                d.cb = Marshal.SizeOf(d);

                if (!EnumDisplayDevices(null, (uint)monitorIndex, ref d, 0))
                {
                    Logger.Error($"Monitor index {monitorIndex} not found.");
                    Console.WriteLine("Monitor index not found.");
                    return;
                }

                DEVMODE dm = new DEVMODE();
                dm.dmSize = (short)Marshal.SizeOf(typeof(DEVMODE));

                if (!EnumDisplaySettings(d.DeviceName, ENUM_CURRENT_SETTINGS, ref dm))
                {
                    Logger.Error("Failed to retrieve current display settings.");
                    Console.WriteLine("Failed to get current settings.");
                    return;
                }

                dm.dmPelsWidth = width;
                dm.dmPelsHeight = height;
                dm.dmBitsPerPel = depth;
                dm.dmDisplayFrequency = frequency;
                dm.dmFields = DM_PELSWIDTH | DM_PELSHEIGHT | DM_BITSPERPEL | DM_DISPLAYFREQUENCY;

                Logger.Info($"Attempting to set resolution for monitor {monitorIndex}: {width}x{height}, {depth}-bit, {frequency}Hz");

                int result = ChangeDisplaySettingsEx(d.DeviceName, ref dm, IntPtr.Zero, CDS_UPDATEREGISTRY | CDS_RESET, IntPtr.Zero);
                if (result == DISP_CHANGE_SUCCESSFUL)
                {
                    Logger.Info("Resolution changed successfully.");
                    Console.WriteLine("Resolution changed successfully.");
                }
                else
                {
                    Logger.Error($"ChangeDisplaySettingsEx failed with code {result}");
                    Console.WriteLine($"Failed to change resolution. Error code: {result}");
                }
            }
            catch (FormatException fe)
            {
                Logger.Error("Invalid argument format: " + fe.Message);
                Console.WriteLine("Error: One or more arguments are not valid numbers.");
            }
            catch (IndexOutOfRangeException ie)
            {
                Logger.Error("Argument index error: " + ie.Message);
                Console.WriteLine("Error: Missing required arguments.");
            }
            catch (Exception ex)
            {
                Logger.Error("Unexpected error: " + ex.Message);
                Console.WriteLine("An unexpected error occurred. See log for details.");
            }
        }

        static void ListMonitors()
        {
            try
            {
                uint deviceIndex = 0;
                DISPLAY_DEVICE d = new DISPLAY_DEVICE();
                d.cb = Marshal.SizeOf(d);

                Console.WriteLine("Connected Monitors:");
                while (EnumDisplayDevices(null, deviceIndex, ref d, 0))
                {
                    DEVMODE dm = new DEVMODE();
                    dm.dmSize = (short)Marshal.SizeOf(typeof(DEVMODE));

                    string resolution = EnumDisplaySettings(d.DeviceName, ENUM_CURRENT_SETTINGS, ref dm)
                        ? $"{dm.dmPelsWidth}x{dm.dmPelsHeight} @ {dm.dmDisplayFrequency}Hz, {dm.dmBitsPerPel}-bit"
                        : "Unable to retrieve settings";

                    Console.WriteLine($"  [{deviceIndex}] {d.DeviceName} - {d.DeviceString}");
                    Console.WriteLine($"       {resolution}");

                    Logger.Info($"Monitor {deviceIndex}: {d.DeviceName} - {d.DeviceString}");
                    Logger.Info($"Resolution: {resolution}");

                    deviceIndex++;
                    d.cb = Marshal.SizeOf(d);
                }
            }
            catch (Exception ex)
            {
                Logger.Error("Error while listing monitors: " + ex.Message);
                Console.WriteLine("Failed to list monitors. See log for details.");
            }
        }
    }
}